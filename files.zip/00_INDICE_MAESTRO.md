# BIOINFORMÁTICA: DE SECUENCIAS A SISTEMAS
## Índice Maestro Del Libro

**Autor:** Emilio García Morán  
**Universidad de Valladolid**

---

## ARCHIVOS LISTOS PARA DESCARGAR

✅ **Cap_BloqueV_01_Modelos_Probabilistas.md** - COMPLETO
✅ **01_Secuenciacion_ADN.md** - COMPLETO  
✅ **00A_Unix_Terminal.md** - COMPLETO

---

Ver contenido completo del índice en el archivo.
